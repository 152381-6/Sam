import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../store/slices/productSlice';
import { addToCart } from '../store/slices/cartSlice';
import { addNotification } from '../store/slices/uiSlice';

const HomePage = () => {
  const dispatch = useDispatch();
  const { products, featuredProducts, loading, error } = useSelector((state) => state.products);
  
  useEffect(() => {
    // For demonstration purposes, we're using mock data
    // In a real app, this would fetch from an API
    dispatch(fetchProducts());
  }, [dispatch]);
  
  const handleAddToCart = (product) => {
    dispatch(addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    }));
    
    dispatch(addNotification({
      type: 'success',
      message: `${product.name} added to your cart`,
    }));
  };
  
  // Featured products section
  const renderFeaturedProducts = () => {
    if (loading) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 animate-pulse">
              <div className="w-full h-48 bg-gray-300 dark:bg-gray-700 rounded-md mb-4"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded mb-2"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-2/3 mb-4"></div>
              <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded"></div>
            </div>
          ))}
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="text-center py-8">
          <p className="text-red-500 dark:text-red-400">Error: {error}</p>
          <button
            onClick={() => dispatch(fetchProducts())}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      );
    }
    
    // Mock data for featured products if none available from store
    const mockFeaturedProducts = [
      {
        id: '1',
        name: 'Wireless Earbuds',
        description: 'High-quality wireless earbuds with noise cancellation',
        price: 89.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Earbuds',
        rating: 4.5,
      },
      {
        id: '2',
        name: 'Smart Watch',
        description: 'Fitness tracking with heart rate monitoring',
        price: 199.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Watch',
        rating: 4.8,
      },
      {
        id: '3',
        name: 'Laptop Backpack',
        description: 'Water-resistant laptop backpack with USB charging port',
        price: 49.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Backpack',
        rating: 4.2,
      },
      {
        id: '4',
        name: 'Bluetooth Speaker',
        description: 'Portable bluetooth speaker with 20-hour battery life',
        price: 79.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Speaker',
        rating: 4.7,
      },
    ];
    
    const productsToShow = featuredProducts?.length > 0 ? featuredProducts : mockFeaturedProducts;
    
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {productsToShow.map((product) => (
          <div key={product.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg">
            <Link to={`/product/${product.id}`}>
              <div className="h-48 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                />
              </div>
            </Link>
            <div className="p-4">
              <Link to={`/product/${product.id}`}>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">{product.name}</h3>
              </Link>
              <div className="flex items-center mb-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <svg 
                      key={i} 
                      className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                      fill="currentColor" 
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">({product.rating})</span>
              </div>
              <p className="text-xl font-bold text-gray-900 dark:text-white mb-2">${product.price.toFixed(2)}</p>
              <button
                onClick={() => handleAddToCart(product)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>
    );
  };
  
  return (
    <div>
      {/* Hero section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Welcome to Dokan</h1>
            <p className="text-xl mb-8">Your one-stop marketplace for quality products and reliable services.</p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/shop" className="px-8 py-3 bg-white text-blue-600 font-medium rounded-md hover:bg-gray-100 transition-colors">
                Browse Products
              </Link>
              <Link to="/seller/register" className="px-8 py-3 border border-white text-white font-medium rounded-md hover:bg-white/10 transition-colors">
                Become a Seller
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img 
              src="https://placehold.co/600x400/e2e8f0/1e293b?text=Shopping+Illustration" 
              alt="Shopping Illustration" 
              className="max-w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
      
      {/* Categories section */}
      <section className="py-12 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">Shop by Category</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'Electronics', icon: '📱', color: 'from-blue-500 to-blue-700' },
              { name: 'Fashion', icon: '👕', color: 'from-pink-500 to-pink-700' },
              { name: 'Home & Living', icon: '🛋️', color: 'from-green-500 to-green-700' },
              { name: 'Health & Beauty', icon: '💄', color: 'from-purple-500 to-purple-700' },
              { name: 'Sports', icon: '⚽', color: 'from-red-500 to-red-700' },
              { name: 'Toys & Games', icon: '🎮', color: 'from-yellow-500 to-yellow-700' },
              { name: 'Books', icon: '📚', color: 'from-indigo-500 to-indigo-700' },
              { name: 'Automotive', icon: '🚗', color: 'from-gray-500 to-gray-700' },
            ].map((category) => (
              <Link 
                key={category.name} 
                to={`/shop?category=${encodeURIComponent(category.name)}`} 
                className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className={`h-24 flex items-center justify-center bg-gradient-to-r ${category.color} text-white text-4xl`}>
                  <span role="img" aria-label={category.name}>{category.icon}</span>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white text-center">{category.name}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      {/* Featured products section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">Featured Products</h2>
          {renderFeaturedProducts()}
        </div>
      </section>
      
      {/* Promotion banner */}
      <section className="py-12 bg-gray-100 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl shadow-xl overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2 p-12">
                <h2 className="text-3xl font-bold text-white mb-4">Summer Sale</h2>
                <p className="text-xl text-white/90 mb-6">Get up to 50% off on selected items this summer!</p>
                <Link 
                  to="/shop?sale=true" 
                  className="inline-block px-8 py-3 bg-white text-blue-600 font-medium rounded-md hover:bg-blue-50 transition-colors"
                >
                  Shop Now
                </Link>
              </div>
              <div className="md:w-1/2">
                <img 
                  src="https://placehold.co/800x400/e2e8f0/1e293b?text=Summer+Sale" 
                  alt="Summer Sale" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 text-center">What Our Customers Say</h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-12 text-center">Trusted by thousands of customers worldwide</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Sarah Johnson',
                role: 'Regular Customer',
                image: 'https://placehold.co/100x100/e2e8f0/1e293b?text=SJ',
                quote: 'Dokan has transformed how I shop online. The variety of products and seamless checkout experience keeps me coming back!'
              },
              {
                name: 'Mark Thompson',
                role: 'Tech Enthusiast',
                image: 'https://placehold.co/100x100/e2e8f0/1e293b?text=MT',
                quote: 'As someone who loves gadgets, Dokan is my go-to marketplace. Their electronics selection is unmatched, and delivery is always prompt.'
              },
              {
                name: 'Jessica Chen',
                role: 'Fashion Blogger',
                image: 'https://placehold.co/100x100/e2e8f0/1e293b?text=JC',
                quote: 'I recommend Dokan to all my followers. The fashion collection is trendy, affordable, and the quality never disappoints!'
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="h-12 w-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="text-lg font-medium text-gray-900 dark:text-white">{testimonial.name}</h4>
                    <p className="text-gray-500 dark:text-gray-400">{testimonial.role}</p>
                  </div>
                </div>
                <div className="mb-4">
                  {[...Array(5)].map((_, i) => (
                    <svg 
                      key={i} 
                      className="h-5 w-5 text-yellow-400 inline-block"
                      fill="currentColor" 
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-600 dark:text-gray-300 italic">"{testimonial.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Newsletter section */}
      <section className="py-12 bg-gray-100 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Stay Updated</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">Subscribe to our newsletter for exclusive offers and updates</p>
          </div>
          
          <div className="max-w-md mx-auto">
            <form className="flex">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-1 px-4 py-3 rounded-l-md border-t border-b border-l border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 text-white font-medium rounded-r-md hover:bg-blue-700 transition-colors"
              >
                Subscribe
              </button>
            </form>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              By subscribing, you agree to our Privacy Policy.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;