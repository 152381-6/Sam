import { createBrowserRouter } from 'react-router-dom';

// Layouts
import MainLayout from '../components/layouts/MainLayout';
import DashboardLayout from '../components/layouts/DashboardLayout';
import AuthLayout from '../components/layouts/AuthLayout';

// Public pages
import HomePage from '../pages/home/HomePage';
import ShopPage from '../pages/shop/ShopPage';
import ProductPage from '../pages/product/ProductPage';
import CartPage from '../pages/cart/CartPage';
import CheckoutPage from '../pages/checkout/CheckoutPage';
import LoginPage from '../pages/auth/LoginPage';
import RegisterPage from '../pages/auth/RegisterPage';
import ForgotPasswordPage from '../pages/auth/ForgotPasswordPage';
import ContactPage from '../pages/contact/ContactPage';
import AboutPage from '../pages/about/AboutPage';

// Customer pages
import ProfilePage from '../pages/profile/ProfilePage';
import OrdersPage from '../pages/profile/OrdersPage';
import WishlistPage from '../pages/profile/WishlistPage';

// Seller/Store pages
import SellerDashboard from '../pages/seller/SellerDashboard';
import SellerProducts from '../pages/seller/SellerProducts';
import SellerOrders from '../pages/seller/SellerOrders';
import SellerInventory from '../pages/seller/SellerInventory';
import SellerReports from '../pages/seller/SellerReports';
import SellerSettings from '../pages/seller/SellerSettings';

// Delivery pages
import DeliveryDashboard from '../pages/delivery/DeliveryDashboard';
import DeliveryOrders from '../pages/delivery/DeliveryOrders';
import DeliveryTracking from '../pages/delivery/DeliveryTracking';
import DeliveryFinance from '../pages/delivery/DeliveryFinance';
import DeliverySettings from '../pages/delivery/DeliverySettings';

// Admin pages
import AdminDashboard from '../pages/admin/AdminDashboard';
import AdminUsers from '../pages/admin/AdminUsers';
import AdminStores from '../pages/admin/AdminStores';
import AdminDelivery from '../pages/admin/AdminDelivery';
import AdminSettings from '../pages/admin/AdminSettings';
import AdminReports from '../pages/admin/AdminReports';

// Error pages
import NotFoundPage from '../pages/error/NotFoundPage';

// Auth components
import ProtectedRoute from '../components/common/ProtectedRoute';

const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    errorElement: <NotFoundPage />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'shop', element: <ShopPage /> },
      { path: 'product/:productId', element: <ProductPage /> },
      { path: 'cart', element: <CartPage /> },
      { path: 'checkout', element: <ProtectedRoute><CheckoutPage /></ProtectedRoute> },
      { path: 'contact', element: <ContactPage /> },
      { path: 'about', element: <AboutPage /> },
      { 
        path: 'profile',
        element: <ProtectedRoute roles={['customer']}><ProfilePage /></ProtectedRoute>
      },
      { 
        path: 'orders',
        element: <ProtectedRoute roles={['customer']}><OrdersPage /></ProtectedRoute>
      },
      { 
        path: 'wishlist',
        element: <ProtectedRoute roles={['customer']}><WishlistPage /></ProtectedRoute>
      },
    ],
  },
  {
    path: '/auth',
    element: <AuthLayout />,
    children: [
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'forgot-password', element: <ForgotPasswordPage /> },
    ],
  },
  {
    path: '/seller',
    element: <ProtectedRoute roles={['seller']}><DashboardLayout userType="seller" /></ProtectedRoute>,
    children: [
      { index: true, element: <SellerDashboard /> },
      { path: 'products', element: <SellerProducts /> },
      { path: 'orders', element: <SellerOrders /> },
      { path: 'inventory', element: <SellerInventory /> },
      { path: 'reports', element: <SellerReports /> },
      { path: 'settings', element: <SellerSettings /> },
    ],
  },
  {
    path: '/delivery',
    element: <ProtectedRoute roles={['delivery']}><DashboardLayout userType="delivery" /></ProtectedRoute>,
    children: [
      { index: true, element: <DeliveryDashboard /> },
      { path: 'orders', element: <DeliveryOrders /> },
      { path: 'tracking', element: <DeliveryTracking /> },
      { path: 'finance', element: <DeliveryFinance /> },
      { path: 'settings', element: <DeliverySettings /> },
    ],
  },
  {
    path: '/admin',
    element: <ProtectedRoute roles={['admin']}><DashboardLayout userType="admin" /></ProtectedRoute>,
    children: [
      { index: true, element: <AdminDashboard /> },
      { path: 'users', element: <AdminUsers /> },
      { path: 'stores', element: <AdminStores /> },
      { path: 'delivery', element: <AdminDelivery /> },
      { path: 'reports', element: <AdminReports /> },
      { path: 'settings', element: <AdminSettings /> },
    ],
  },
]);

export default router;