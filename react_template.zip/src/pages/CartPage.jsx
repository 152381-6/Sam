import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { removeFromCart, updateCartItemQuantity, clearCart } from '../store/slices/cartSlice';
import { addNotification } from '../store/slices/uiSlice';

const CartPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { cartItems, cartTotal } = useSelector((state) => state.cart);
  const { isLoggedIn } = useSelector((state) => state.auth);
  
  const [couponCode, setCouponCode] = useState('');
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  
  const subtotal = cartTotal;
  const shipping = cartItems.length > 0 ? 5.99 : 0;
  const tax = subtotal * 0.08; // 8% tax rate
  const totalAmount = subtotal + shipping + tax - discountAmount;
  
  const handleQuantityChange = (id, quantity) => {
    if (quantity < 1) return;
    
    dispatch(updateCartItemQuantity({ id, quantity }));
  };
  
  const handleRemoveItem = (id, name) => {
    dispatch(removeFromCart(id));
    dispatch(addNotification({
      type: 'info',
      message: `${name} removed from your cart`,
    }));
  };
  
  const handleApplyCoupon = (e) => {
    e.preventDefault();
    
    if (!couponCode.trim()) {
      dispatch(addNotification({
        type: 'error',
        message: 'Please enter a coupon code',
      }));
      return;
    }
    
    setIsApplyingCoupon(true);
    
    // Simulate API call to apply coupon
    setTimeout(() => {
      if (couponCode.toUpperCase() === 'DOKAN20') {
        const discount = subtotal * 0.2; // 20% discount
        setDiscountAmount(discount);
        dispatch(addNotification({
          type: 'success',
          message: 'Coupon applied successfully! 20% discount',
        }));
      } else {
        dispatch(addNotification({
          type: 'error',
          message: 'Invalid coupon code',
        }));
      }
      setIsApplyingCoupon(false);
    }, 1000);
  };
  
  const handleCheckout = () => {
    if (!isLoggedIn) {
      dispatch(addNotification({
        type: 'info',
        message: 'Please log in to proceed with checkout',
      }));
      navigate('/auth/login', { state: { from: '/cart' } });
      return;
    }
    
    navigate('/checkout');
  };
  
  const handleClearCart = () => {
    dispatch(clearCart());
    dispatch(addNotification({
      type: 'info',
      message: 'Your cart has been cleared',
    }));
  };
  
  if (cartItems.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <svg className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <h2 className="mt-2 text-lg font-medium text-gray-900 dark:text-white">Your cart is empty</h2>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Looks like you haven't added any products to your cart yet.
          </p>
          <div className="mt-6">
            <Link to="/shop" className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
              Start Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Your Cart</h1>
      
      <div className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-8">
          {/* Cart items */}
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden mb-8">
            <ul className="divide-y divide-gray-200 dark:divide-gray-700">
              {cartItems.map((item) => (
                <li key={item.id} className="p-4 sm:p-6">
                  <div className="flex items-center sm:items-start">
                    <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-md border border-gray-200 dark:border-gray-700">
                      <img
                        src={item.image || 'https://placehold.co/300x300/e2e8f0/1e293b?text=Product'}
                        alt={item.name}
                        className="h-full w-full object-cover object-center"
                      />
                    </div>
                    
                    <div className="ml-6 flex-1 flex flex-col">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="text-base font-medium text-gray-900 dark:text-white">
                            <Link to={`/product/${item.id}`} className="hover:text-blue-600 dark:hover:text-blue-400">
                              {item.name}
                            </Link>
                          </h3>
                          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            Unit Price: ${item.price.toFixed(2)}
                          </p>
                        </div>
                        <p className="text-base font-medium text-gray-900 dark:text-white">
                          ${(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex border border-gray-300 dark:border-gray-600 rounded-md">
                          <button
                            type="button"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                            className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                            disabled={item.quantity <= 1}
                          >
                            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4" />
                            </svg>
                          </button>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                            className="w-12 text-center border-none focus:outline-none dark:bg-gray-700 dark:text-white"
                          />
                          <button
                            type="button"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                            className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                          >
                            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                            </svg>
                          </button>
                        </div>
                        
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id, item.name)}
                          className="text-sm font-medium text-red-600 hover:text-red-500 dark:text-red-400 dark:hover:text-red-300"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            
            <div className="border-t border-gray-200 dark:border-gray-700 px-4 py-6 sm:px-6">
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => navigate('/shop')}
                  className="text-sm font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Continue Shopping
                </button>
                <button
                  type="button"
                  onClick={handleClearCart}
                  className="text-sm font-medium text-red-600 hover:text-red-500 dark:text-red-400 dark:hover:text-red-300"
                >
                  Clear Cart
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-4">
          {/* Order summary */}
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
            <div className="px-4 py-6 sm:px-6">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">Order Summary</h2>
              
              <div className="mt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Subtotal</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">${subtotal.toFixed(2)}</p>
                </div>
                
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Shipping</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">${shipping.toFixed(2)}</p>
                </div>
                
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Tax (8%)</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">${tax.toFixed(2)}</p>
                </div>
                
                {discountAmount > 0 && (
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-green-600 dark:text-green-400">Discount</p>
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">- ${discountAmount.toFixed(2)}</p>
                  </div>
                )}
                
                <div className="border-t border-gray-200 dark:border-gray-700 pt-4 flex items-center justify-between">
                  <p className="text-base font-medium text-gray-900 dark:text-white">Total</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">${totalAmount.toFixed(2)}</p>
                </div>
              </div>
              
              {/* Coupon code */}
              <div className="mt-6">
                <form onSubmit={handleApplyCoupon} className="flex space-x-2">
                  <input
                    type="text"
                    placeholder="Coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="flex-1 min-w-0 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:text-white"
                  />
                  <button
                    type="submit"
                    disabled={isApplyingCoupon}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isApplyingCoupon ? 'Applying...' : 'Apply'}
                  </button>
                </form>
                <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                  Try "DOKAN20" for 20% off
                </p>
              </div>
              
              <div className="mt-6">
                <button
                  type="button"
                  onClick={handleCheckout}
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Proceed to Checkout
                </button>
              </div>
              
              <div className="mt-6 flex items-center">
                <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                  Secure checkout powered by Stripe
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;