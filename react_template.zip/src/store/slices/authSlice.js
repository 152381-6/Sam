import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Mock API calls (to be replaced with actual API implementation)
const loginApi = (credentials) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Mock user data
      resolve({
        id: 'user123',
        name: 'John Doe',
        email: credentials.email,
        role: 'customer', // Options: customer, seller, delivery, admin
        token: 'mock-jwt-token'
      });
    }, 1000);
  });
};

export const login = createAsyncThunk(
  'auth/login',
  async (credentials, { rejectWithValue }) => {
    try {
      const response = await loginApi(credentials);
      // Store the token in localStorage
      localStorage.setItem('dokan_token', response.token);
      return response;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const logout = createAsyncThunk(
  'auth/logout',
  async () => {
    localStorage.removeItem('dokan_token');
    return null;
  }
);

const initialState = {
  user: null,
  token: localStorage.getItem('dokan_token') || null,
  isAuthenticated: !!localStorage.getItem('dokan_token'),
  loading: false,
  error: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.loading = false;
        state.isAuthenticated = true;
        state.user = action.payload;
        state.token = action.payload.token;
      })
      .addCase(login.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(logout.fulfilled, (state) => {
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
      });
  },
});

export const { clearError } = authSlice.actions;

export default authSlice.reducer;