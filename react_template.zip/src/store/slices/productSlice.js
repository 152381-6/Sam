import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Mock data - to be replaced with actual API calls
const productsData = [
  {
    id: '1',
    name: 'Wireless Headphones',
    description: 'High-quality wireless headphones with noise cancellation',
    price: 129.99,
    category: 'electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=300',
    rating: 4.5,
    stock: 50,
    sellerId: 'seller1',
    storeId: 'store1',
    storeName: 'TechGadgets'
  },
  {
    id: '2',
    name: 'Smart Watch',
    description: 'Track your fitness and stay connected',
    price: 199.99,
    category: 'electronics',
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?q=80&w=300',
    rating: 4.2,
    stock: 35,
    sellerId: 'seller1',
    storeId: 'store1',
    storeName: 'TechGadgets'
  },
  {
    id: '3',
    name: 'Cotton T-Shirt',
    description: 'Comfortable and stylish t-shirt for everyday wear',
    price: 24.99,
    category: 'clothing',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=300',
    rating: 4.0,
    stock: 100,
    sellerId: 'seller2',
    storeId: 'store2',
    storeName: 'FashionHub'
  },
  {
    id: '4',
    name: 'Organic Coffee Beans',
    description: 'Premium organic coffee beans from sustainable farms',
    price: 14.99,
    category: 'food',
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?q=80&w=300',
    rating: 4.8,
    stock: 80,
    sellerId: 'seller3',
    storeId: 'store3',
    storeName: 'OrganicDelights'
  }
];

// Mock API fetch function
const fetchProductsApi = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(productsData);
    }, 1000);
  });
};

export const fetchProducts = createAsyncThunk(
  'products/fetchProducts',
  async (_, { rejectWithValue }) => {
    try {
      const products = await fetchProductsApi();
      return products;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  products: [],
  filteredProducts: [],
  categories: [],
  selectedProduct: null,
  loading: false,
  error: null,
};

const productSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    setSelectedProduct: (state, action) => {
      state.selectedProduct = action.payload;
    },
    filterProducts: (state, action) => {
      const { category, priceRange, rating, search } = action.payload;
      
      let filtered = [...state.products];
      
      if (category && category !== 'all') {
        filtered = filtered.filter(product => product.category === category);
      }
      
      if (priceRange && priceRange.length === 2) {
        filtered = filtered.filter(
          product => product.price >= priceRange[0] && product.price <= priceRange[1]
        );
      }
      
      if (rating) {
        filtered = filtered.filter(product => product.rating >= rating);
      }
      
      if (search) {
        const searchLower = search.toLowerCase();
        filtered = filtered.filter(
          product => 
            product.name.toLowerCase().includes(searchLower) || 
            product.description.toLowerCase().includes(searchLower)
        );
      }
      
      state.filteredProducts = filtered;
    },
    clearFilters: (state) => {
      state.filteredProducts = state.products;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload;
        state.filteredProducts = action.payload;
        
        // Extract unique categories
        const categories = new Set();
        action.payload.forEach(product => {
          categories.add(product.category);
        });
        state.categories = Array.from(categories);
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setSelectedProduct, filterProducts, clearFilters } = productSlice.actions;

export default productSlice.reducer;