import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, Outlet } from 'react-router-dom';
import PropTypes from 'prop-types';

const ProtectedRoute = ({ allowedRoles = [] }) => {
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const navigate = useNavigate();

  useEffect(() => {
    // If user is not authenticated, redirect to login
    if (!isAuthenticated) {
      navigate('/auth/login', { state: { from: window.location.pathname } });
      return;
    }

    // If allowedRoles is specified and user's role is not in allowedRoles, redirect to unauthorized
    if (allowedRoles.length > 0 && !allowedRoles.includes(user?.role)) {
      navigate('/unauthorized');
      return;
    }
  }, [isAuthenticated, user, allowedRoles, navigate]);

  // If not authenticated or not authorized, don't render children
  if (!isAuthenticated || (allowedRoles.length > 0 && !allowedRoles.includes(user?.role))) {
    return null;
  }

  // Otherwise, render the children
  return <Outlet />;
};

ProtectedRoute.propTypes = {
  allowedRoles: PropTypes.arrayOf(PropTypes.string),
};

export default ProtectedRoute;